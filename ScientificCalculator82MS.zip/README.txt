Scientific Calculator 82MS - Instructions

1. Run the JAR file:
   > java -jar ScientificCalculator82MS.jar

2. Or double-click 'calculator.bat' (Windows only).

3. Requires Java installed (Java 8+).
